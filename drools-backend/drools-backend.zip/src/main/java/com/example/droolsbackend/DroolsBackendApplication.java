package com.example.droolsbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DroolsBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DroolsBackendApplication.class, args);
	}

}
