package com.example.droolsbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DroolsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
